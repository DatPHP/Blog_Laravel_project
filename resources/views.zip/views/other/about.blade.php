 @extends('layouts.master')
 @section('content')
 
 <div class="row">
     <div class="col-md-12">
         <p class="quote"> About me </p>
     </div>
     
 </div>
 
 <div class="row">
     <div class="col-md-12">
         <p> Theo đại diện ban tổ chức, tại sự kiện, 
             phụ huynh và học sinh còn có dịp "mục sở thị"
             những dự án thực tế của sinh viên, tìm hiểu các chương trình học phù hợp,
             tư vấn hướng nghiệp, gặp gỡ và lắng nghe chia sẻ từ đại diện các công ty,
             tập đoàn đầu ngành, cựu sinh viên và sinh viên RMIT. Các đại diện gồm 
             ông Nguyễn Tuấn Anh - Giám đốc Dreamincubator; Paul Nguyễn - Giám đốc điều hành,
             DealersEdge Asia; Anna Phan - Tư vấn Marketing - L Concepts, Nhà đồng sáng lập Ladan.</p>
     </div>
     
 </div>
 
 @endsection
     
