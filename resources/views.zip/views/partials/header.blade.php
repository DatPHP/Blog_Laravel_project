<style>
    
    li{
        padding-left: 20px;
        padding-right: 20px
    }
    
</style>



 <nav class="navbar navbar-default">
     <div class="container-fluid">
         <div class="navbar-header">
              <style>
    .fixed-left.ad6h.ad.check-ads-1 { right: unset !important; }
</style>


<nav class="navbar navbar-expand-lg navbar-light bg-info">
    <a class="navbar-brand" href="#" style="pading-left:400px;">
    MY BLOG
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#demo-navbar" aria-controls="demo-navbar" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="demo-navbar">
    <ul class="navbar-nav mr-auto">
    <!--Form code starts here-->
    <nav class="navbar navbar-expand-sm ">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="/">Home</a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="{{route('blog.index')}}">Blog</a>
    </li>
     <li class="nav-item">
      <a class="nav-link" href="{{route('other.about')}}">About</a>
    </li>
    
    
    @if(!Auth::check())
     <li class="nav-item">
      <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
    </li>
     <li class="nav-item">
      <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
     </li>
     
     @else
      <li >
      <a href="{{route('admin.index')}} " >Posts</a>  
      </li>
      
    <li class="nav-item">
      <a class="nav-link" href="{{route('admin.index')}}">Admin</a>
    </li>
    
       <li >
         <a class="dropdown-item" href="{{ route('logout') }}"
            onclick="event.preventDefault();
            document.getElementById('logout-form').submit();">
            {{ __('Logout') }}
        </a>

        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
            {{csrf_field()}}
        </form>

        </li>
        @endif                 
  </ul>
</nav>
    
    
   
    
    
    
    
    
    <form action="/search" method="POST" role="search">
    {{ csrf_field() }}
    <div class="input-group">
        <input type="text" class="form-control" name="q"
            placeholder="Search users"> <span class="input-group-btn">
            <button type="submit" class="btn btn-default">
                <span class="glyphicon glyphicon-search"></span>
            </button>
        </span>
    </div>
</form>
    
    
 

<!--Form code ends here -->    
    </ul>
  </div>
</nav>







<!------------------------------------------------------------------------------

<header id="header">
    <div class="page-wrap">
        <div class="logo">
            <h3>Dat Blog</h3>
                
        </div>
        <nav class="menu-bar">
            <span class="hamburger">
            <ul class="main-nav" style="float:left;">
                <li><a title="Trang chủ" href="/"> Trang chủ</a></li>
                 <li><a title="Blog" href="{{route('blog.index')}}"> Blog</a></li>
                  <li><a title="About" href="{{route('other.about')}}"> About</a></li>
                                             
            </ul>
                </span>
        </nav>
        
        <div class="search-bar" style="padding-left:150px;">
            <!--<form name="search-box" id="search-box" action="/?mod=archive&amp;act=search" method="POST">
                <input name="search" type="text" placeholder="Tìm kiếm trên VTC News" />
                <span class="fa fa-search"></span>
            </form>-->	
            
            
            
           
            <!---------------------------------------------------------------------------------------------------------------
			<form style="margin-top:3px;" method="get" action="https://www.google.com/cse" target="_blank">
            <input type="hidden" name="cx" value="008387462101762501841:bgn7mqd3654">
            <input type="hidden" name="ie" value="UTF-8">
			<input style="width:232px;color:#333;border:1px solid #dadad0;padding-left:5px" type="text" name="q" spellcheck="false" autocomplete="off" value="Nhập tin tức cần tìm" onblur="javascript:if(this.value==''){this.value='Nhập tin tức cần tìm'}" onfocus="javascript:if(this.value=='Nhập tin tức cần tìm'){this.value=''}">
            <input style="background-color:yellowgreen; color:#ffffff;border:1px solid #dadad0" type="submit" value="Tìm">
			</form>
        </div>
        
        <div class="clearfix"></div>
    </div>
	<div class="clearfix"></div>
</header>
      --------------------------------------------------------------------------------------------------->       
         </div> 
     </div>   
 </nav>
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 